// All your js resides here
/*
* Function to get all movie list from db.json file
*/
function getAllMovies() {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function() {
        if ( this.readyState == 4 && this.status == 200 ) {
            var respObj = JSON.parse(this.responseText);
            var htmlBody = populateMovieBox(respObj);
            document.getElementById("listcont").innerHTML = htmlBody;
        }
    };
    var responseObj = httpRequest.open('GET', 'http://localhost:3000/movies', false);
    var myJson = JSON.stringify(responseObj);
    console.log(myJson);
    httpRequest.send();
}

/*
* Function to get all favorite movie list from db.json file
*/
function getFavMovies() {
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function() {
        if ( this.readyState == 4 && this.status == 200 ) {
            var respObj = JSON.parse(this.responseText);
            var htmlBody = populateMovieBox(respObj);
            document.getElementById("listcont").innerHTML = htmlBody;
        }
    };
    var responseObj = httpRequest.open('GET', 'http://localhost:3000/favorites', false);
    var myJson = JSON.stringify(responseObj);
    console.log(myJson);
    httpRequest.send();
}

/*
* Common function to populate movie components
*/
function populateMovieBox(respObj) {
    var movieComponent = "";
        respObj.forEach((movie) => {
            console.log(movie.posterurl);
            var boxComp = '<div class="col-lg-4 col-md-6 mb-4">'+
                            '<div class="card h-100">'+
                                '<a href="#"><img class="card-img-top" src="' + movie.posterurl + '" alt="movie image"></a>'+
                                '<div class="card-body">'+
                                    '<h4 class="card-title"><a href="#">' + movie.title + '</a></h4>'+
                                    '<h5>$24.99</h5>'+
                                    '<div class="details">'+
                                        '<p class="card-text">' + movie.storyline + '</p>'+
                                    '</div>'+
                                '</div>'+
                                '<div class="card-footer">'+
                                    '<button type="button" class="btn-primary" onclick="addToFavorites('+movie.id+')">Add to Favorites</button>'+
                                '</div></div></div>';
            movieComponent += boxComp;
        });
        
    //}
    return movieComponent;
}

function toggleActive(id) {
    if(id === 'liMov') {
        $('#liMov').addClass('active');
        $('#liFav').removeClass('active');
    } else {
        $('#liMov').removeClass('active');
        $('#liFav').addClass('active');
    }
}

function addToFavorites(_id) {
    //e.preventDefault();
    var httpRequest = new XMLHttpRequest();
    httpRequest.onreadystatechange = function() {
        if ( this.readyState == 4 && this.status == 200 ) {
            var respObj = JSON.parse(this.responseText);
            //var htmlBody = populateMovieBox(respObj);
            //document.getElementById("listcont").innerHTML = htmlBody;
        }
    };
    var responseObj = httpRequest.open('GET', 'http://localhost:3000/movies?id='+_id);
    var myJson = JSON.stringify(responseObj);
    console.log(myJson);
    httpRequest.send();
}