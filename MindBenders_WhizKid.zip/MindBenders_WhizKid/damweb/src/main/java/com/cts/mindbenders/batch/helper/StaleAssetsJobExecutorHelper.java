package com.cts.mindbenders.batch.helper;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.mindbenders.batch.dao.StaleAssetsJobExecutorDAO;
import com.cts.mindbenders.models.HotelBean;
import com.cts.mindbenders.models.StalableAsset;

@Component
public class StaleAssetsJobExecutorHelper {
	private static final Logger LOGGER = LoggerFactory.getLogger(StaleAssetsJobExecutorHelper.class);

	@Autowired
	StaleAssetsJobExecutorDAO staleBatchDAO;

	public Set<String> executeStaleJob() {
		Set<String> hotelCodes = new HashSet<>();
		Map<String, List<StalableAsset>> staleAssetsM = new LinkedHashMap<>();
		try {
			// step 1 - select all the assets which have ACTIVE status
			List<StalableAsset> staleAssets = staleBatchDAO.getStalableAssets();
			// step2 - execute batch update
			if (staleAssets != null && !staleAssets.isEmpty()) {
				staleBatchDAO.executeBatchUpdateForDigiAssets(staleAssets);
			}
			// System.out.println("7777777777777777777777............");

			for (StalableAsset sa : staleAssets) {
				if (!staleAssetsM.containsKey(sa.getHotelCode())) {
					List<StalableAsset> temp = new ArrayList<>();
					temp.add(sa);
					staleAssetsM.put(sa.getHotelCode(), temp);
				} else {
					staleAssetsM.get(sa.getHotelCode()).add(sa);
				}
			}
			// System.out.println("hotelCodes : "+staleAssetsM);

			List<HotelBean> hotels = new ArrayList<>();

			// System.out.println("88888888888888888............");
			for (Map.Entry<String, List<StalableAsset>> entry : staleAssetsM.entrySet()) {
				// System.out.println("entry.getKey()"+entry.getKey());
				HotelBean hBean = staleBatchDAO.populateHotelByCode(entry.getKey());
				int activeAssetCount = staleBatchDAO.getCountOfAllActiveAssetsOfHotelByHotelId(hBean.getHotelId());
				// System.out.println("activeAssetCount : "+activeAssetCount);
				// generate 360 score = weighted index x no of active assets
				double score = new BigDecimal(hBean.getWeightedIndex() * activeAssetCount)
						.setScale(2, RoundingMode.HALF_UP).doubleValue();
				hBean.setScore(score);

				hotels.add(hBean);

				hotelCodes.add(entry.getKey());

			}

			if (!hotels.isEmpty()) {
				staleBatchDAO.updateHotel360ScoreBatch(hotels);
			}
			// System.out.println("9999999999999999999............");

		} catch (Exception e) {
			// TODO: handle exception
			LOGGER.error("Exception occured during execution of stale Job...", e);
		}

		return hotelCodes;
	}

}
