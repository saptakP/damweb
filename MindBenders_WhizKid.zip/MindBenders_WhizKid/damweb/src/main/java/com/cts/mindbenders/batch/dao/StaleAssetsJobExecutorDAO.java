package com.cts.mindbenders.batch.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cts.mindbenders.models.HotelBean;
import com.cts.mindbenders.models.StalableAsset;

@Component
public interface StaleAssetsJobExecutorDAO {

	public List<StalableAsset> executeStaleJob();

	void executeBatchUpdateForDigiAssets(List<StalableAsset> staleAssets);

	List<StalableAsset> getStalableAssets();

	HotelBean populateHotelByCode(String hotelCode);

	int getTotalRoomsOfHotel(int hotelId);

	int getCountOfAllActiveAssetsOfHotelByHotelId(int hotelId);

	void updateHotel360ScoreBatch(List<HotelBean> hBean);
}
