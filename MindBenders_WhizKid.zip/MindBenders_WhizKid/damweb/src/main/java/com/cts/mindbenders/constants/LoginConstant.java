package com.cts.mindbenders.constants;

public class LoginConstant {
	
	public static final String LOGIN_USERID_SESSION_ATTRIBUTE = "userid";
	public static final String LOGIN_USERNAME_SESSION_ATTRIBUTE = "username";
	public static final String LOGIN_USERBEAN_SESSION_ATTRIBUTE = "userbean";
	public static final String LOGIN_USER_TYPE = "userType";

}
