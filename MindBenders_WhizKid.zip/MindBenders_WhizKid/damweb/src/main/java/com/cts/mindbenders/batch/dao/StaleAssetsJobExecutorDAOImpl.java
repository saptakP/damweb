package com.cts.mindbenders.batch.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.mindbenders.constants.DBQueryConstant;
import com.cts.mindbenders.models.Amenity;
import com.cts.mindbenders.models.HotelBean;
import com.cts.mindbenders.models.StalableAsset;
import com.cts.mindbenders.utils.CommonUtil;

@Repository
@Qualifier("staleBatchDAO")
@Configuration
@PropertySource(value = "classpath:batchdb.properties"/* , ignoreResourceNotFound=true */)
public class StaleAssetsJobExecutorDAOImpl implements StaleAssetsJobExecutorDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaleAssetsJobExecutorDAOImpl.class);

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	@Autowired
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Autowired
	private Environment env;

	@Override
	@Transactional(readOnly = true)
	public List<StalableAsset> getStalableAssets() {

		List<StalableAsset> staleAssets = getJdbcTemplate().query(env.getProperty(DBQueryConstant.GET_STALE_ASSET),
				new RowMapper<StalableAsset>() {

					@Override
					public StalableAsset mapRow(ResultSet rs, int rowNum) throws SQLException {
						StalableAsset details = new StalableAsset();
						details.setAssetDetailsId(rs.getInt("da_details_id"));
						details.setDigitalAssetId(rs.getInt("digital_asset_id"));
						details.setAssetName(rs.getString("asset_name"));
						details.setAssetLocation(rs.getString("digital_asset_location"));
						details.setLastRefreshDate(rs.getDate("last_refresh_date"));
						details.setStatus(rs.getString("status"));
						details.setHotelCode(rs.getString("hotel_code"));
						details.setCreated(rs.getDate("created"));
						details.setUpdated(rs.getDate("updated"));
						return details;
					}

				});

		return staleAssets;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public void executeBatchUpdateForDigiAssets(List<StalableAsset> staleAssets) {

		int num[] = getJdbcTemplate().batchUpdate(env.getProperty(DBQueryConstant.UPDATE_STALE_STATUS),
				new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						StalableAsset asset = staleAssets.get(i);
						ps.setInt(1, asset.getAssetDetailsId());
					}

					@Override
					public int getBatchSize() {
						return staleAssets.size();
					}
				});
		System.out.println("No of rows updated : " + num.length);
	}

	@Override
	public List<StalableAsset> executeStaleJob() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional(readOnly = true)
	public int getCountOfAllActiveAssetsOfHotelByHotelId(int hotelId) {
		return getJdbcTemplate().queryForObject(env.getProperty(DBQueryConstant.GET_ASSET_COUNT_BY_HOTELID),
				new Object[] { hotelId }, Integer.class);
	}

	@Override
	@Transactional(readOnly = true)
	public HotelBean populateHotelByCode(String hotelCode) {
		System.out.println("populateHotelByCode0....start");
		HotelBean bean = (HotelBean) getJdbcTemplate().queryForObject(
				env.getProperty(DBQueryConstant.GET_HOTELS_BY_CODE), new Object[] { hotelCode },
				new RowMapper<HotelBean>() {

					@Override
					public HotelBean mapRow(ResultSet rs, int rowNum) throws SQLException {
						HotelBean hotel = new HotelBean();
						hotel.setHotelId(rs.getInt("hotel_id"));
						hotel.setHotelCode(rs.getString("hotel_code"));
						String amStr = rs.getString("htl_amenities");
						String[] arr = null;
						if (StringUtils.isNotBlank(amStr)) {
							amStr = amStr.substring(amStr.indexOf("[") + 1, amStr.indexOf("]"));
							arr = amStr.split(",");
							List<Amenity> am = new ArrayList<>();
							for (String i : arr) {
								Amenity a = new Amenity();
								a.setAmenityId(Integer.valueOf(i.trim()));
								am.add(a);
							}
							hotel.setHotelAmenities(am);
							// set No of room count of a hotel
							hotel.setNoOfRooms(getTotalRoomsOfHotel(hotel.getHotelId()));
							// set weighted index
							hotel.setWeightedIndex(CommonUtil.calculateWeightedIndex(hotel.getNoOfRooms(), am.size()));

						}
						return hotel;
					}

				});
		System.out.println("populateHotelByCode0....end");
		return bean;
	}

	@Override
	@Transactional(readOnly = true)
	public int getTotalRoomsOfHotel(int hotelId) {
		return getJdbcTemplate().queryForObject(env.getProperty(DBQueryConstant.GET_ROOM_COUNT_BY_HOTELID),
				new Object[] { hotelId }, Integer.class);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public void updateHotel360ScoreBatch(List<HotelBean> hBeans) {

		int num[] = getJdbcTemplate().batchUpdate(env.getProperty(DBQueryConstant.UPDATE_360_SCORE_BY_HOTELID),
				new BatchPreparedStatementSetter() {

					@Override
					public void setValues(PreparedStatement ps, int i) throws SQLException {
						HotelBean hBean = hBeans.get(i);
						ps.setDouble(1, hBean.getScore());
						ps.setDouble(2, hBean.getWeightedIndex());
						ps.setInt(3, hBean.getHotelId());
					}

					@Override
					public int getBatchSize() {
						return hBeans.size();
					}
				});
		System.out.println("No of rows updated : " + num.length);
	}

}
