package com.cts.mindbenders.batch.scheduling;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.cts.mindbenders.batch.helper.StaleAssetsJobExecutorHelper;
import com.cts.mindbenders.utils.MailUtil;

public class StaleAssetsJobExecutor {

	private static final Logger LOGGER = LoggerFactory.getLogger(StaleAssetsJobExecutor.class);

	@Autowired
	StaleAssetsJobExecutorHelper staleAssetsExecutorHelper;

	// @Scheduled(fixedRate=15000)
	@Scheduled(cron = "30 38 22 * * ?")
	public void execute() {
		LOGGER.info("I am called by Spring scheduler");
		Set<String> hotelCodes = staleAssetsExecutorHelper.executeStaleJob();
		LOGGER.info("I am called by Spring scheduler : success");
		System.out.println("DAM JOB....");
		// send mail to hotel owners
		if (!hotelCodes.isEmpty()) {
			MailUtil.notifiyAdminBatch(hotelCodes);
		} else {
			LOGGER.info("No such update has been done");
		}
	}

}
