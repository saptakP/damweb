package com.cts.mindbenders.config;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DBConnectionMgr {
	private static final Logger LOGGER = LoggerFactory.getLogger(DBConnectionMgr.class);
	private static DataSource dataSource;
	
	static {
		try {
			Context context = new InitialContext();
			Context envContext = (Context) context.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/UberotelDB");
		} catch (NamingException ne) {
			LOGGER.error("'jdbc/UberotelDB' not found in JNDI");
			throw new ExceptionInInitializerError("'jdbc/UberotelDB' not found in JNDI");
		}
	}
	
	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}
	
	public static void clearConn(Connection con) {
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
	}
	
	public static void clearConn(ResultSet rs, PreparedStatement psmt, Statement stmt, Connection con) {
		if(rs != null){
			try {
				rs.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
		if(psmt != null){
			try {
				psmt.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
		if(stmt != null){
			try {
				stmt.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
	}
	
	public static void clearConn(ResultSet rs, PreparedStatement psmt, Connection con) {
		if(rs != null){
			try {
				rs.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
		if(psmt != null){
			try {
				psmt.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
	}
	
	public static void clearConn(PreparedStatement psmt, Connection con) {
		if(psmt != null){
			try {
				psmt.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
	}
	
	public static void clearConn(Statement stmt, Connection con) {
		if(stmt != null){
			try {
				stmt.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
		if(con != null){
			try {
				con.close();
			} catch (SQLException e) {
				LOGGER.error("Unable to close connection ::: " + e.getMessage());
			}
		}
	}
	
}
