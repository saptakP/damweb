package com.cts.mindbenders.models;

import java.io.Serializable;

public class Amenity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int amenityId;
	private String amenityName;
	
	public int getAmenityId() {
		return amenityId;
	}
	public void setAmenityId(int amenityId) {
		this.amenityId = amenityId;
	}
	public String getAmenityName() {
		return amenityName;
	}
	public void setAmenityName(String amenityName) {
		this.amenityName = amenityName;
	}
	
	
}
