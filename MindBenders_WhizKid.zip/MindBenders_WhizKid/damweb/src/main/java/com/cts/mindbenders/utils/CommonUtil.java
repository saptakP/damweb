package com.cts.mindbenders.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CommonUtil {

	public static double calculateWeightedIndex(int noOfRooms, int noOfAmenities) {
		/*
		 * Hotel thumb image = 1, Hotel detail image = 3, Room thumb image = 1, Room detail
		 * image = 3, Room Inside/outside video = 2 ,Amenity thumb image =1, Amenity detail
		 * image = 3
		 */
		double index = 100.0 / (4 + 4 * (noOfRooms + noOfAmenities) + noOfRooms * 2);

		return new BigDecimal(index).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}

}
