package com.cts.mindbenders.constants;

public class ReviewConstant {
	public static final String REVIEW_STATE = "PENDING";

}
